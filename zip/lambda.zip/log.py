def log(msg):
    print(f"Added log via function: {msg}")
